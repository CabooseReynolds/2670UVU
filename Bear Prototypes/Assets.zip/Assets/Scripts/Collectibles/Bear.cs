﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bear : MonoBehaviour {
void OnTriggerEnter(Collider other)
     {
         print("Rawr! I'm a bear! FEED ME or DIE!");	 
	}
}